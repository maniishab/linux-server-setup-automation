pwd
ls
ls /
sudo apt update
su -
exit
